import React from 'react';
import {Composition} from 'remotion';
import {Yusratak} from './Video';
export const Root=()=><Composition id="Yusratak" component={Yusratak} durationInFrames={1350} fps={30} width={1920} height={1080}/>;
