import React from 'react';
import {AbsoluteFill,Sequence,interpolate,useCurrentFrame} from 'remotion';
import {loadFont as a} from '@remotion/google-fonts/SpaceGrotesk';
import {loadFont as b} from '@remotion/google-fonts/JetBrainsMono';
a();b();
const C={bg:'#0E1613',panel:'#15201B',line:'rgba(255,255,255,0.10)',acid:'#4FE360',gold:'#C9A24B',cream:'#F6F3EC',muted:'#9DB1A6'};
const SANS="'Space Grotesk',system-ui,sans-serif",MONO="'JetBrains Mono',ui-monospace,monospace";
const ease=t=>t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2;
const I=(f,a,b)=>interpolate(f,a,b,{extrapolateLeft:'clamp',extrapolateRight:'clamp',easing:ease});
const rnd=n=>{const x=Math.sin(n*127.1+311.7)*43758.5453;return x-Math.floor(x)};
const P={background:C.panel,border:'1px solid '+C.line,borderRadius:10};
const Mid={alignItems:'center',justifyContent:'center'};
const typed=(f,s,t)=>t.slice(0,Math.floor(I(f,[s,s+t.length*3],[0,t.length])));
const In=({d=0,style,children})=>{const t=I(useCurrentFrame(),[d,d+12],[0,1]);return <div style={{opacity:t,transform:`translateY(${(1-t)*10}px)`,...style}}>{children}</div>};
const Cap=({d=0,children})=><In d={d} style={{position:'absolute',left:0,right:0,bottom:72,textAlign:'center',fontFamily:SANS,fontSize:26,letterSpacing:'.18em',color:C.cream}}>{children}</In>;
const Step=({children})=><In d={4} style={{position:'absolute',left:96,top:72,fontFamily:MONO,fontSize:22,letterSpacing:'.14em',color:C.acid}}>{children}</In>;
const Dot=({on})=><span style={{width:14,height:14,borderRadius:7,background:on?C.acid:'#3A4A42',display:'inline-block'}}/>;
const Ico=({k,s=64})=><svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={C.cream} strokeWidth="1.5" strokeLinejoin="round" strokeLinecap="round">{k==='w'?<path d="M4 5h16v11H10l-4 4v-4H4z"/>:k==='t'?<path d="M21 3 3 11l7 3 3 7zM10 14l11-11"/>:<><path d="M4 8h4l2-2.5h4L16 8h4v11H4z"/><circle cx="12" cy="13.5" r="3.5"/></>}</svg>;
const Icons=({d=0,style})=><div style={{display:'flex',gap:88,...style}}>{[['w','WhatsApp'],['t','Telegram'],['i','Instagram']].map(([k,l],i)=><In key={k} d={d+i*6} style={{display:'flex',flexDirection:'column',alignItems:'center',gap:14,fontFamily:MONO,fontSize:20,color:C.muted}}><Ico k={k}/>{l}</In>)}</div>;
const Fade=({n,out,children})=>{const f=useCurrentFrame();const o=I(f,[0,12],[0,1])*(out?I(f,[n-out,n],[1,0]):1);return <AbsoluteFill style={{opacity:o}}>{children}</AbsoluteFill>};
const Scn=({from,to,out=12,Body})=><Sequence from={from} durationInFrames={to-from}><Fade n={to-from} out={out}><Body/></Fade></Sequence>;

// 0:00-0:04 HOOK
const S1=()=>{const f=useCurrentFrame();const rows=[['@ovl',8,44],['@kng',32,58],['@zen',44,68]];
return <AbsoluteFill style={Mid}><div style={{width:760,display:'flex',flexDirection:'column',gap:28,fontFamily:MONO,fontSize:60,color:C.cream,marginTop:-120}}>
{rows.map(([h,s,k],i)=><div key={i} style={{display:'flex',justifyContent:'space-between',alignItems:'baseline'}}><span>{typed(f,s,h)}</span><span style={{color:C.muted,fontSize:38,opacity:f<k?.4:1}}>{f<k?'···':'taken'}</span></div>)}</div>
<In d={60} style={{position:'absolute',left:0,right:0,top:700,textAlign:'center',fontFamily:SANS,fontWeight:500,fontSize:52,letterSpacing:'.08em',color:C.cream}}>RARE USERNAMES DON’T WAIT.</In></AbsoluteFill>};

// 0:04-0:09 INTRO
const S2=()=>{const f=useCurrentFrame();
return <AbsoluteFill style={Mid}><In d={0} style={{...P,width:1100,padding:'80px 0 64px',display:'flex',flexDirection:'column',alignItems:'center'}}>
<div style={{fontFamily:SANS,fontWeight:300,fontSize:96,letterSpacing:'.42em',paddingLeft:'.42em',color:C.cream}}>YUSRATAK</div>
<div style={{height:2,width:I(f,[34,66],[0,560]),background:C.gold,opacity:.8,marginTop:16}}/>
<In d={50} style={{fontFamily:MONO,fontSize:28,color:C.muted,marginTop:32}}>real-time username scanner</In>
<Icons d={76} style={{marginTop:64}}/></In>
<Cap d={20}>REAL-TIME USERNAME SCANNER</Cap></AbsoluteFill>};

// 0:09-0:15 STEP 1
const QR=()=>{const g=[];for(let y=0;y<21;y++)for(let x=0;x<21;x++){if((x<7&&y<7)||(x>13&&y<7)||(x<7&&y>13))continue;if(rnd(y*21+x+3)>.52)g.push(<rect key={x+'-'+y} x={x} y={y} width="1" height="1"/>)}
const F=(x,y)=><g key={x+'f'+y}><rect x={x+.5} y={y+.5} width="6" height="6" fill="none" stroke={C.cream} strokeWidth="1"/><rect x={x+2} y={y+2} width="3" height="3"/></g>;
return <svg viewBox="0 0 21 21" width="290" height="290" fill={C.cream}>{g}{F(0,0)}{F(14,0)}{F(0,14)}</svg>};
const S3=()=>{const f=useCurrentFrame();
return <AbsoluteFill style={{...Mid,flexDirection:'row',gap:150}}><Step>1 — CONNECT · QR scan</Step>
<In d={6} style={{width:360,height:640,border:'2px solid rgba(255,255,255,.3)',borderRadius:44,display:'flex',...Mid}}><QR/></In>
<div style={{display:'flex',flexDirection:'column',gap:16}}>{[1,2,3,4,5].map(n=>{const d=34+(n-1)*9;const on=f>=d+9;
return <In key={n} d={d} style={{...P,width:720,height:96,padding:'0 36px',display:'flex',alignItems:'center',gap:24,fontFamily:MONO,fontSize:28,color:C.cream}}><Dot on={on}/><span>LANE {n}</span><span style={{marginLeft:'auto',color:on?C.acid:C.muted}}>{on?'online':'···'}</span></In>})}</div>
<Cap d={20}>ONE QR SCAN</Cap></AbsoluteFill>};

// 0:15-0:20 STEP 2
const S4=()=>{const f=useCurrentFrame();
const rows=[['Length','4–6'],['Starts with','go'],['Ends with','—'],['Must contain','ld'],['Exclude','x, z']];
return <AbsoluteFill style={Mid}><Step>2 — SET FILTERS</Step>
<In d={0} style={{...P,width:900,padding:'44px 48px',display:'flex',flexDirection:'column',gap:18,fontFamily:MONO}}>
{rows.map(([l,v],i)=>{const s=12+i*20;const hl=l==='Must contain';
return <div key={l} style={{display:'flex',alignItems:'center',justifyContent:'space-between',height:72,padding:'0 24px',borderRadius:8,border:'1px solid '+(hl&&f>s?C.acid:C.line),background:hl&&f>s?'rgba(79,227,96,.07)':'transparent',opacity:I(f,[s,s+8],[.25,1])}}><span style={{fontSize:24,color:C.muted}}>{l}</span><span style={{fontSize:34,color:C.cream}}>{typed(f,s,v)}</span></div>})}
<In d={112} style={{display:'flex',alignItems:'center',gap:20,padding:'0 24px',height:48,fontSize:24,color:C.muted}}>Pattern{[1,0,1,1,0,1].map((q,i)=><span key={i} style={{width:18,height:18,background:q?C.cream:'transparent',border:'1.5px solid '+C.cream,borderRadius:q?0:9}}/>)}</In></In>
<Cap d={30}>LENGTH · STARTS · ENDS · CONTAINS</Cap></AbsoluteFill>};

// 0:20-0:28 STEP 3
const hd=(n,i)=>{if(i<0)return'';const L=4+Math.floor(rnd(n*91+i*7)*3);let s='';for(let k=0;k<L;k++)s+='abcdefghijklmnopqrstuvwxyz'[Math.floor(rnd(n*1013+i*37+k*5)*26)];return'@'+s};
const S5=()=>{const f=useCurrentFrame();const v=I(f,[0,110,230],[8412,9207,10000]);const sp=[4,5,6,7,9];
return <AbsoluteFill><Step>3 — PARALLEL LANES · thousands of checks/hour</Step>
<In d={6} style={{position:'absolute',right:96,top:56,textAlign:'right',fontFamily:MONO,color:C.muted,fontSize:20,letterSpacing:'.14em'}}>CHECKS THIS HOUR<div style={{fontSize:92,color:C.cream,letterSpacing:0,fontVariantNumeric:'tabular-nums',marginTop:6}}>{Math.round(v).toLocaleString('en-US')+(v>9990?'+':'')}</div></In>
<div style={{position:'absolute',left:96,right:96,top:260,display:'flex',flexDirection:'column',gap:16}}>{sp.map((s,n)=>{const i=Math.floor(f/s);
return <In key={n} d={n*4} style={{...P,height:128,padding:'0 36px',display:'flex',alignItems:'center',gap:36,fontFamily:MONO}}>
<span style={{display:'flex',alignItems:'center',gap:16,fontSize:22,color:C.muted,width:180}}><Dot on/>LANE {n+1}</span>
<div style={{display:'flex',flexDirection:'column',fontSize:26,lineHeight:'34px'}}>{[0,1,2].map(k=><div key={k} style={{color:C.cream,opacity:[1,.5,.22][k]}}>{i-k>=0?'→ '+hd(n+1,i-k)+'   ':''}<span style={{color:C.muted}}>{i-k>=0?'taken':''}</span></div>)}</div></In>})}</div></AbsoluteFill>};

// 0:28-0:34 DISCOVERY
const S6=()=>{const f=useCurrentFrame();const av=f>=24;const pulse=av?.06+.05*Math.sin((f-24)/9):0;const lk=I(f,[104,122],[-7,0]);
return <AbsoluteFill style={{...Mid,flexDirection:'row',gap:140}}><Cap d={60}>INSTANT TELEGRAM ALERT</Cap>
<div style={{display:'flex',flexDirection:'column',alignItems:'center'}}>
<In d={0} style={{...P,width:780,height:120,padding:'0 40px',display:'flex',alignItems:'center',justifyContent:'space-between',fontFamily:MONO,fontSize:44,color:C.cream,borderColor:av?C.acid:C.line,background:`rgba(79,227,96,${pulse})`}}><span>→ @golld</span><span style={{fontSize:34,color:av?C.acid:C.muted}}>{av?'AVAILABLE':'···'}</span></In>
<In d={100} style={{display:'flex',alignItems:'center',gap:20,marginTop:56,fontFamily:MONO,fontSize:26,letterSpacing:'.14em',color:C.cream}}><svg width="72" height="72" viewBox="0 0 24 24" fill="none" stroke={C.gold} strokeWidth="1.5" strokeLinecap="round"><rect x="5" y="11" width="14" height="9" rx="1.5"/><path d="M8 11V8a4 4 0 0 1 8 0v3" transform={`translate(0 ${lk})`}/></svg>AUTO-CLAIMED</In></div>
<div style={{width:360,height:620,border:'2px solid rgba(255,255,255,.3)',borderRadius:44,padding:'64px 24px',opacity:I(f,[56,76],[0,1]),transform:`translateX(${I(f,[56,86],[80,0])}px)`}}>
<div style={{...P,padding:20,display:'flex',alignItems:'center',gap:16,fontFamily:MONO,fontSize:22,color:C.cream}}><Ico k="t" s={44}/><span>@golld — <span style={{color:C.acid}}>AVAILABLE</span></span></div></div></AbsoluteFill>};

// 0:34-0:38 PROGRESS
const S7=()=>{const f=useCurrentFrame();const p=f<72?I(f,[8,52],[0,64]):I(f,[72,112],[64,100]);const ps=f>=54&&f<72;
return <AbsoluteFill style={Mid}><div style={{width:1000,marginTop:-100}}>
<div style={{display:'flex',justifyContent:'space-between',alignItems:'center',fontFamily:MONO,fontSize:34,color:C.cream,marginBottom:28,height:44}}><span style={{fontSize:22,letterSpacing:'.14em',color:C.muted,border:'1px solid '+C.line,borderRadius:6,padding:'6px 14px',opacity:ps?1:0}}>PAUSED</span><span style={{fontVariantNumeric:'tabular-nums'}}>{Math.round(p)}%</span></div>
<div style={{height:10,borderRadius:5,background:'rgba(255,255,255,.08)'}}><div style={{height:10,borderRadius:5,background:C.acid,width:p+'%'}}/></div>
<Icons d={80} style={{justifyContent:'center',marginTop:96}}/></div>
<In d={6} style={{position:'absolute',left:0,right:0,bottom:72,textAlign:'center',fontFamily:SANS,fontSize:28,letterSpacing:'.14em',color:C.cream}}>PROGRESS SAVED — NO NAME CHECKED TWICE.</In></AbsoluteFill>};

// 0:38-0:45 CLOSE
const S8=()=>{const f=useCurrentFrame();
return <AbsoluteFill style={Mid}><div style={{transform:`scale(${1+.03*f/210})`,...P,width:1100,padding:'80px 0',display:'flex',flexDirection:'column',alignItems:'center'}}>
<div style={{fontFamily:SANS,fontWeight:300,fontSize:96,letterSpacing:'.42em',paddingLeft:'.42em',color:C.cream}}>YUSRATAK</div>
<div style={{height:2,width:560,background:C.gold,opacity:.8,marginTop:16}}/>
<In d={30} style={{marginTop:56,background:C.acid,color:C.bg,fontFamily:MONO,fontSize:34,padding:'22px 56px',borderRadius:999}}>tools.hablas.tech</In>
<In d={50} style={{marginTop:36,fontFamily:SANS,fontSize:26,color:C.cream,opacity:.6}}>Start your first scan in a minute.</In></div>
<div style={{position:'absolute',inset:0,background:'#000',opacity:I(f,[165,210],[0,1])}}/></AbsoluteFill>};

const Stage=()=><div style={{width:1920,height:1080,position:'relative',overflow:'hidden',background:C.bg}}>
<Scn from={0} to={120} Body={S1}/><Scn from={120} to={270} Body={S2}/><Scn from={270} to={450} Body={S3}/><Scn from={450} to={600} Body={S4}/><Scn from={600} to={840} Body={S5}/><Scn from={840} to={1020} Body={S6}/><Scn from={1020} to={1140} Body={S7}/><Scn from={1140} to={1350} out={0} Body={S8}/></div>;
export const Yusratak=Stage;
