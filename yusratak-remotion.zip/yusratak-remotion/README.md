# Yusratak - How it works (45s, 16:9, 4K, 30fps)
npm install
npm run studio   # live preview
npm run render   # -> out/yusratak.mp4 (3840x2160)

Sound design (ambient pad, lane/flip ticks, chime, padlock resonance) is in public/sfx.wav and already wired.

Voiceover: generate one mp3 per line with any TTS (warm, neutral English), save as public/vo/01.mp3 ... 08.mp3, then set VO=true in src/Video.jsx.
01 (0:00) Every minute, rare usernames disappear.
02 (0:04) Yusratak is a real-time username scanner - built for hunters.
03 (0:09) Start with WhatsApp. Connect your lanes with one QR scan...
04 (0:15) ...and set your filters: length... starts with... ends with... must contain.
05 (0:20) Then watch parallel lanes sweep thousands of names per hour.
06 (0:28) The moment one is available - you get an instant Telegram alert. And on premium plans, it's auto-claimed with a real number before anyone else gets it.
07 (0:34) Stop anytime. Your progress is saved - no name is ever checked twice. WhatsApp. Telegram. Instagram. One scanner.
08 (0:38) Yusratak. Start your first scan in a minute - at tools dot hablas dot tech.
