# Yusratak — How it works (45s, 16:9, 4K, 30fps)
npm install
npm run studio   # live preview
npm run render   # -> out/yusratak.mp4 (1920x1080 scaled x2 = 3840x2160, silent)
Audio: add <Audio src={staticFile('vo.mp3')}/> inside Stage later.
